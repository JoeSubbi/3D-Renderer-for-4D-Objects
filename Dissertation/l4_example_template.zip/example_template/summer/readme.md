# Summer work

* PROJECT NAME
* YOUR NAME
* STUDENT_ID
* SUPERVISOR NAME

Use this file to keep a report stating what you completed over the summer. The following is an *template* that you can use as a basis. 

## Research completed

## Ideas developed

## Concerns or risks identified



